require 'test/unit'
require "./tc_twodarray.rb"
require "./tc_terrain.rb"
require "./tc_swimmingpool.rb"
require "./tc_helipad.rb"
