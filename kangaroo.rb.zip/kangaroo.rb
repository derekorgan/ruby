class Die
  def initialize
      @mystats = {:NORTH => 0, :SOUTH => 0, :EAST => 0, :WEST => 0 }  
  end
      
  #return one of :NORTH :SOUTH :EAST, :WEST with equal probablity
  def throw
    r = rand(4)
    
    if r == 0
      @mystats[:NORTH] += 1
      @thisthrow = ":NORTH"
    elsif r == 1
      @mystats[:SOUTH] += 1
      @thisthrow = ":SOUTH"
    elsif r == 2
      @mystats[:EAST] += 1
      @thisthrow = ":EAST"
    else
      @mystats[:WEST] += 1
      @thisthrow = ":WEST"
    end
    
  end

  # return hash table describing stats of throws so far  e.g. {:NORTH=> 35, SOUTH:=>42, EAST=>}
  def stats
    @mystats
  end
  
end

class Point
  attr_reader :x, :y
  
  def initialize x, y
    @x = x
    @y = y
  end
  
  def go_north! i
    @x += i
  end
  
  def go_south! i
    @x -= i
  end
  
  def go_east! i
    @y += i
  end

  def go_west! i
    @y -= i
  end

  
end

class Kangaroo
  
  def initialize dimension
    @dimension = dimension
    @p = Point.new 0,0
    @d = Die.new
  end
  
  #take a random hop in one direction
  def hop!
    
  end
  
  # return true if at at boundary of space
  def at_boundary?  
  end
  
  # return true if at home
  def at_home
    if @p.x == @dimension-1 && @p.y == @dimesion-1
      true
    else
      false
    end
    
  end
  
  # return current location (a point)
  def location
    @p
  end

  
end

class RandomWalk < Kangaroo
  
  attr_accessor :hops
  
  def initialize dimension
    super dimension
    
    @hops = 0

  end
  
  # start the simulation
  def start! 
    
    
  end
  
  # reutnr final location of the kangaroo
  def final_location
    
  end
  
  # return number of hops the kangaroo took durning the simulation
  def no_of_hops
    
  end
  
  # return hash table describing die stats
  def stats
    
  end
  
end



rw = RandomWalk.new 10


