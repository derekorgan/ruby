class Die
  def initialize
      @mystats = {:NORTH => 0, :SOUTH => 0, :EAST => 0, :WEST => 0 }  
  end
      
  #return one of :NORTH :SOUTH :EAST, :WEST with equal probablity
  def throw
    r = rand(4)
    
    if r == 0
      @mystats[:NORTH] += 1
      @thisthrow = ":NORTH"
    elsif r == 1
      @mystats[:SOUTH] += 1
      @thisthrow = ":SOUTH"
    elsif r == 2
      @mystats[:EAST] += 1
      @thisthrow = ":EAST"
    else
      @mystats[:WEST] += 1
      @thisthrow = ":WEST"
    end
    
  end

  # return hash table describing stats of throws so far  e.g. {:NORTH=> 35, SOUTH:=>42, EAST=>}
  def stats
    @mystats
  end
  
end

class Point
  attr_reader :x, :y
  
  def initialize x, y
    @x = x
    @y = y
  end
  
  def move! direction, i
    case direction
    when ":NORTH"
      @x += i
    when ":SOUTH"
      @x -= i    
    when ":EAST"
      @y += i
    when ":WEST"
      @y += i
    end

  end
  

  
end

class Kangaroo
  
  def initialize dimension
    @dimension = dimension
    @p = Point.new 0,0
    @d = Die.new
    
  end
  
  #take a random hop in one direction
  def hop!
   direction = @d.throw
   
   # If at the boundary we want to recursively call hop! until we get direction we can go inside area.
   if at_boundary?
     if (@notx == direction || @noty == direction)
        hop!
     end
      
   end
   
   @p.move! direction, 1
  end
  
  # return true if at at boundary of space
  def at_boundary?
    b = false
    if @p.x == 0 
      b = true
      @notx = ":SOUTH" 
    end
    if @p.x == @dimension -1
      b = true
      @notx = ":NORTH"
    end  
    if @p.y == 0 
      b = true
      @noty = ":WEST"
    end
    if @p.y == @dimension-1
      b = true
      @noty = ":EAST"
    end
    
  
  end
  
  # return true if at home
  def at_home?
    if @p.x == @dimension-1 && @p.y == @dimension-1
      true
    else
      false
    end
    
  end
  
  # return current location (a point)
  def location
    @p
  end

  
end

class RandomWalk < Kangaroo
  
  attr_accessor :hops
  
  def initialize dimension
    super dimension
    
    @hops = 0

  end
  
  # start the simulation
  def start! 
    while (!at_home?)
      hop!
    end
    
  end
  
  # reutnr final location of the kangaroo
  def final_location
    
  end
  
  # return number of hops the kangaroo took durning the simulation
  def no_of_hops
    
  end
  
  # return hash table describing die stats
  def stats
    
  end
  
end



rw = RandomWalk.new 10
p rw.location
rw.hop!
rw.hop!
p rw.location


