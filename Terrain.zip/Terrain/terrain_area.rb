require "terrain.rb"

class terrain_area

end
