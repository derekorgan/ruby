require "datafile.rb"
require "terrain.rb"
require "swimming_pool.rb"

file = DataFile.new('terrain.dat', 'r')
lines = Array.new

file.read_file {|x| lines << x}

ms = lines[0].to_i
pool_size = lines[ms+1].to_i

t = Terrain.new(ms)
t.populate(lines)
puts t.highest_point
puts t.mean
puts t.s_dev

sp = SwimmingPool.new(pool_size, t)
puts sp.best_location










