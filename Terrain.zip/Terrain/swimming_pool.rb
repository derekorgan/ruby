require "terrain.rb"

class SwimmingPool < Terrain
	attr_reader :lx,:ly

	def initialize(size, base_terrain)
		super size 
		@bt = base_terrain	
		if (size >= @bt.size)
			raise "The Pool Size is too big. It must be smaller thant he base terrain"
		end
		# location of this terrain on base terrain
		@lx = @ly = 0
	end

	def best_location 
		lowest = low_sdev = -1
		# we only want to tranverse to max start positions 
		# e.g. base terrain size minus size of pool
		max = @bt.size-1-size 
		
		(0..max).each do |y|
			(0..max).each do |x|	
				
				@bt.get_block(size, x,y) do |value|
					push value
				end
				reset # reset the pointer to 0,0

				m = mean
				if m < lowest || lowest == -1
					@lx, @ly = x, y
					lowest = m
					low_sdev = s_dev
				elsif m == lowest # if mean is the same as lowest
					if s_dev < low_sdev 
						@lx, @ly = x, y
					end
				end

			end
		end
		
		# populate the matrix for the pool terrain in the best location		
		@bt.get_block(size, @lx, @ly) do |value|
			push value
		end
		reset

		"#{@lx},#{@ly}"
	end
end
