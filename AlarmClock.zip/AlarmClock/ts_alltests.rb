require 'test/unit'
require 'tc_clock.rb'
require 'tc_alarm_clock.rb'
require 'tc_reverse_clock.rb'